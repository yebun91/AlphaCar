package favorite;

public class FavoriteVO {

	private int fav_number;
	private String customer_email;
	private int store_number;
	
	
	
	public int getFav_number() {
		return fav_number;
	}
	public void setFav_number(int fav_number) {
		this.fav_number = fav_number;
	}
	public String getCustomer_email() {
		return customer_email;
	}
	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}
	public int getStore_number() {
		return store_number;
	}
	public void setStore_number(int store_number) {
		this.store_number = store_number;
	}
	
	
	
	
	
	

}
