package state;

import java.util.Date;

public class StateVO {
	private int inventory_number ;
	private int store_number     ;
	private int sensor_id        ;
	private String now_state        ;
	private Date create_date      ;
	private Date change_date      ;
}
