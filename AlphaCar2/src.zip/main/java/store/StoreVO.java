package store;

public class StoreVO {
	private int store_number               ;
	private String customer_email             ;
	private String store_name                 ;
	private String store_addr                 ;
	private String store_tel                  ;
	private String store_time                 ;
	private String store_dayoff               ;
	private String introduce                  ;
	private String picture                    ;
	private int inventory                  ;
	private String store_price                ;
	private String store_master_name          ;
	private String store_registration_number  ;
	private int store_favorite_cnt         ;

	

	public int getStore_number() {
		return store_number;
	}
	public void setStore_number(int store_number) {
		this.store_number = store_number;
	}
	public String getCustomer_email() {
		return customer_email;
	}
	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}
	public String getStore_name() {
		return store_name;
	}
	public void setStore_name(String store_name) {
		this.store_name = store_name;
	}
	public String getStore_addr() {
		return store_addr;
	}
	public void setStore_addr(String store_addr) {
		this.store_addr = store_addr;
	}
	public String getStore_tel() {
		return store_tel;
	}
	public void setStore_tel(String store_tel) {
		this.store_tel = store_tel;
	}
	public String getStore_time() {
		return store_time;
	}
	public void setStore_time(String store_time) {
		this.store_time = store_time;
	}
	public String getStore_dayoff() {
		return store_dayoff;
	}
	public void setStore_dayoff(String store_dayoff) {
		this.store_dayoff = store_dayoff;
	}
	public String getIntroduce() {
		return introduce;
	}
	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public int getInventory() {
		return inventory;
	}
	public void setInventory(int inventory) {
		this.inventory = inventory;
	}
	public String getStore_price() {
		return store_price;
	}
	public void setStore_price(String store_price) {
		this.store_price = store_price;
	}
	public String getStore_master_name() {
		return store_master_name;
	}
	public void setStore_master_name(String store_master_name) {
		this.store_master_name = store_master_name;
	}
	public String getStore_registration_number() {
		return store_registration_number;
	}
	public void setStore_registration_number(String store_registration_number) {
		this.store_registration_number = store_registration_number;
	}
	public int getStore_favorite_cnt() {
		return store_favorite_cnt;
	}
	public void setStore_favorite_cnt(int store_favorite_cnt) {
		this.store_favorite_cnt = store_favorite_cnt;
	}
	
	
	}
